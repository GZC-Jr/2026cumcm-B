# 问题三、问题四可复现仿真实验项目

本项目将问题三和问题四分别组织为独立实验目录，只生成数据结果，不生成图片或图表。

## 项目结构

```text
simulation_reproducible/
├── runner.py                 # 公共并行实验与统计逻辑
├── Q3/
│   ├── algorithm.py          # 问题三算法与本地仿真环境
│   ├── run_experiment.py     # 问题三实验入口
│   └── results/
│       ├── cases.csv         # 300组逐案例数据
│       ├── summary.csv       # 7项核心指标
│       └── summary.json      # 汇总数据与复现参数
└── Q4/
    ├── algorithm.py          # 问题四算法与本地仿真环境
    ├── run_experiment.py     # 问题四实验入口
    └── results/
        ├── cases.csv
        ├── summary.csv
        └── summary.json
```

## 默认实验设置

- 每个问题运行300组随机案例
- 共同随机种子范围：`2026091200`—`2026091499`
- 默认最多使用8个并行进程
- 实验使用算法代码自带的 `LocalBackend` 本地合成环境

## 运行方法

在项目根目录执行：

```bash
python Q3/run_experiment.py
python Q4/run_experiment.py
```

快速检查可以减少案例数：

```bash
python Q3/run_experiment.py --cases 2 --workers 1
python Q4/run_experiment.py --cases 2 --workers 1
```

如需完整复现，请不要使用快速检查命令覆盖随项目交付的300组结果；直接执行默认命令即可重新生成完整结果。

## 汇总指标

`summary.csv` 仅包含：

1. 随机案例数
2. 全部清除成功率
3. 干扰源总数
4. 单源平均定位清除时间
5. 每局平均定位清除时间
6. 每局平均程序运行时间
7. 每局平均检测次数

程序运行时间会受机器性能和系统负载影响，其余虚拟仿真指标在相同代码、参数和随机种子下可复现。
